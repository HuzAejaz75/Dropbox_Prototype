package com.amishra.exception;

import com.amishra.util.ErrorCodes;

public class CustomException1 extends BaseException {

	public CustomException1() {
		super( ErrorCodes.CUSTOM_EXCEPTION_1);

	}

}
