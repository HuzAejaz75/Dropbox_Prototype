package com.amishra.exception;

public class BaseException extends RuntimeException {	
    public BaseException(String message){
        super(message);
    }
}
