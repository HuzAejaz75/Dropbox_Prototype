package com.amishra.exception;

import com.amishra.util.ErrorCodes;

public class CustomException2 extends BaseException {

	public CustomException2() {		
		super(ErrorCodes.CUSTOM_EXCEPTION_1);
	}

	
}
