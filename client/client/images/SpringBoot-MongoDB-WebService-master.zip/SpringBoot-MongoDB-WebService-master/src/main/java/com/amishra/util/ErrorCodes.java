package com.amishra.util;

public interface ErrorCodes {

<<<<<<< HEAD
    String CUSTOM_EXCEPTION_1="Id cannot be less than 0";
    String CUSTOM_EXCEPTION_2="custom exception 2";

=======
    String NegativeIDMsg="Id cannot be less than 0!";
    String ZeroRecordsFoundMsg="0 records of the requested entity found!";
    
>>>>>>> 6c8a76ce2d2a290c4b0409cadfbfafcee6d55c13
}
